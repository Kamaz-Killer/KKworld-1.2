This folder contains optimized renders of the Git Extensions logo.

The original SVG file from which the icons were rendered is in the `Artwork` folder.
