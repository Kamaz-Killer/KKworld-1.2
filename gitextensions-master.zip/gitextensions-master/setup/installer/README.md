## Building installers for Git Extensions

See the [wiki](https://github.com/gitextensions/gitextensions/wiki/Build-instructions).
