﻿using System.Reflection;

[assembly: AssemblyDescription("GitExtensions translation app")]
