﻿namespace GitCommands;

public enum CommitMessageType
{
    Normal = 0,
    Merge
}
