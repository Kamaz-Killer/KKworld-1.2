﻿using System.Xml.Serialization;

namespace GitCommands.UserRepositoryHistory;

[Serializable]
public class Repository
{
    private string? _path;

    public enum RepositoryAnchor
    {
        [XmlEnum(Name = "Pinned")]
        AnchoredInTop,
        [XmlEnum(Name = "AllRecent")]
        AnchoredInRecent,
        None
    }

    // required by XmlSerializer
    private Repository()
    {
        Anchor = RepositoryAnchor.None;
    }

    public Repository(string path)
        : this()
    {
        Path = path;
    }

    public RepositoryAnchor Anchor { get; set; }

    public string? Category { get; set; }

    public string Path
    {
        get => _path ?? string.Empty;
        set => _path = value;
    }

    public string GetParentPath()
    {
        if (Path.StartsWith(@"\\") || !Directory.Exists(Path))
        {
            return string.Empty;
        }

        DirectoryInfo dir = new(Path);
        if (dir.Parent is null)
        {
            return Path;
        }

        return dir.Parent.FullName;
    }

    public override string ToString()
    {
        return Path + " (" + Anchor + ")";
    }
}
