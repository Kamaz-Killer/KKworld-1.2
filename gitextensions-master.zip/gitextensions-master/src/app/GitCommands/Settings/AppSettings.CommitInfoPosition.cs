﻿namespace GitCommands;

public enum CommitInfoPosition
{
    // DO NOT RENAME THESE -- doing so will break user preferences
    BelowList = 0,
    LeftwardFromList = 1,
    RightwardFromList = 2
}
