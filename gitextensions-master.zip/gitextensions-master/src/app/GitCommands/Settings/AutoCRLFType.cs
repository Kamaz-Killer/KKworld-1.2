﻿namespace GitCommands.Settings;

public enum AutoCRLFType
{
    @true,
    input,
    @false
}
