﻿namespace GitCommands;

public enum RevisionSortOrder
{
    // DO NOT RENAME THESE -- doing so will break user preferences
    GitDefault,
    AuthorDate,
    Topology
}
