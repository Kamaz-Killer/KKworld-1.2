﻿namespace GitCommands;

public enum ShorteningRecentRepoPathStrategy
{
    // DO NOT RENAME THESE -- doing so will break user preferences
    None,
    MostSignDir,
    MiddleDots
}
