﻿namespace GitCommands;

public enum TruncatePathMethod
{
    // DO NOT RENAME THESE -- doing so will break user preferences
    None,
    Compact,
    TrimStart,
    FileNameOnly
}
