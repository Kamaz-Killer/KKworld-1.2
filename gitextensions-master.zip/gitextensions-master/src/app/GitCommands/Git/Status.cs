﻿namespace System;

internal static partial class NativeMethods
{
    internal const int STATUS_CONTROL_C_EXIT = -1073741510; // 0xC000013A
}
