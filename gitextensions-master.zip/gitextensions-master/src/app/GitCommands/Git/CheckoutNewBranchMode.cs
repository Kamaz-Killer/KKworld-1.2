﻿namespace GitCommands.Git;

public enum CheckoutNewBranchMode
{
    DontCreate,
    Create,
    Reset
}
