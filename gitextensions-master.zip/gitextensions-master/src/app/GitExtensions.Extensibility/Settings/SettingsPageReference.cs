﻿namespace GitExtensions.Extensibility.Settings;

/// <summary>
/// to jump to a specific page
///
/// TODO: extend with attributes to jump to specific control on settingspage.
/// </summary>
public abstract class SettingsPageReference
{
}
