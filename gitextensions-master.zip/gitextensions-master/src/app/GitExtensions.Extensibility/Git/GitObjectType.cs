﻿namespace GitExtensions.Extensibility.Git;

public enum GitObjectType
{
    None = 0,
    Commit,
    Tree,
    Blob
}
