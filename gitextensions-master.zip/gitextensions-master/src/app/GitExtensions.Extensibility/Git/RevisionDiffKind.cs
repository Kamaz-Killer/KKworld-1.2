namespace GitExtensions.Extensibility.Git;

public enum RevisionDiffKind
{
    DiffAB = 0,
    DiffALocal,
    DiffBLocal
}
