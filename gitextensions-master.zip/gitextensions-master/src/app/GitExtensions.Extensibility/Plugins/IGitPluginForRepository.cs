namespace GitExtensions.Extensibility.Plugins;

public interface IGitPluginForRepository : IGitPlugin
{
}
