﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("GitExtensions.Extensibility.Tests")]
[assembly: InternalsVisibleTo("GitCommands")]
